window.onload = function() {
	const rus = document.querySelector('.form__field-country');
	const langs = document.querySelector('.form__field-country-more');
	rus.addEventListener('click', () => {
		langs.classList.toggle('active');
	});
	langs.addEventListener('click', () => {
		langs.classList.toggle('active');
	});
}